public class Bank {
    private double amt;
    private double[] interactions;
    private int interactionCount;

    
    public Bank(double initialAmount) {
        this.amt = initialAmount;
        this.interactions = new double[100];  
    }

    
    public void deposit(double amount) {
        this.amt += amount;
        interactions[interactionCount++] = amount; 
    }

   
    public void withdraw(double amount) {
        this.amt -= amount;
        interactions[interactionCount++] = -amount; 
    }

    
    public void listInteractions() {
        System.out.println("List of all transactions:");
        for (int i = 0; i < interactionCount; i++) {
            System.out.println("Transaction " + (i + 1) + ": " + interactions[i]);
        }
    }

    
    public double getBalance() {
        return this.amt;
    }

    public static void main(String[] args) {
        
        Bank myBank = new Bank(700);

        
        myBank.deposit(100);  
        myBank.withdraw(150);  
        myBank.deposit(20);  
        myBank.withdraw(30);  

        
        myBank.listInteractions();

        
        System.out.println("Final balance: " + myBank.getBalance());
    }
}